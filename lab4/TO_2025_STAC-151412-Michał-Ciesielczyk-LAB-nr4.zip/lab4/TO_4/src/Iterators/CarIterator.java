package Iterators;

import Model.Car;

public interface CarIterator {
    boolean hasNext();
    Car next();
}
