package Model;

public enum EventCar {
    GOING,
    WORKING,
    FALSE_ALARM,
    RETURNING,
    RETURNED,
    NONE
}
