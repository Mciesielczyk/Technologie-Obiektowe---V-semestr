package Model;

public enum EventType {
    PZ,MZ
}
