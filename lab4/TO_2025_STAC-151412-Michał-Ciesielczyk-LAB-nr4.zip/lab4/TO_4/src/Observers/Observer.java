package Observers;

public interface Observer {
    void update(String message);
}
