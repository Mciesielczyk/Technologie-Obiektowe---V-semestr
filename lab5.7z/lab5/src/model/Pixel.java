package model;

public record Pixel(int x, int y, int value) {}
